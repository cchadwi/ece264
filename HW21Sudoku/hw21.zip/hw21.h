
#ifndef HW21_H
#define HW21_H


int solveSudoku(int sudoku[9][9], int x, int y);
void printArray(int sudoku[9][9]);
int gridCheck(int sudoku[9][9], int row, int col, int count);

#endif
